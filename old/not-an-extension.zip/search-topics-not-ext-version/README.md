# Search Topics

Search Topics MCP "not an extension" for the phpBB 3.2 Forum Software Package

## Installation

First of all you should read this page for the official MCP extention wiki
https://wiki.phpbb.com/Tutorial.Adding_modules

1. Copy this "not an extension" to phpBB/
2. Go to "ACP" > "System" > "Moderator Control Panel" and create a new module named "Search Topics"
3. Click the new "Search Topics" module link to open the sub-category
4. From the add module combobox select "Search Topics [mcp_main_search]" > "View Forum" and click add module
5. Enable the "View Forum" module
6. Enable the "Search Topics" module
7. Purge the phpBB Cache

## License

[GPLv2](license.txt)
